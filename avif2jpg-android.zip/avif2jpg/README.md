# AVIF a JPG (Android)

Aplicación Android nativa en Kotlin para convertir imágenes AVIF a JPG por lotes.

## Funciones
- Selección múltiple de hasta 100 imágenes mediante Android Photo Picker.
- Conversión secuencial por lotes con progreso.
- Calidad JPG ajustable entre 50 y 100 (predeterminada: 95).
- Guarda en `Pictures/AVIF a JPG` usando MediaStore.
- No solicita permiso general de almacenamiento ni transmite archivos por Internet.

## Generar el APK sin ordenador (GitHub Actions)
1. Sube el contenido de esta carpeta a un repositorio de GitHub llamado, por ejemplo, `avif-a-jpg`.
2. Abre la pestaña **Actions** del repositorio.
3. Selecciona **Crear APK Android** y pulsa **Run workflow** (o realiza un cambio en `main`, que también inicia la compilación).
4. Cuando termine correctamente, entra en la ejecución y descarga el artefacto **AVIF-a-JPG-APK**.
5. Dentro del ZIP descargado encontrarás `app-debug.apk`, que podrás instalar en tu Android.

El flujo de trabajo instala Java, Android SDK y Gradle en los servidores de GitHub y compila el APK allí.

## Compilación local alternativa
- Android Studio.
- JDK 17.
- Android SDK 35.
- Android 12 (API 31) o posterior para decodificación AVIF integrada.

Ejecuta `gradle :app:assembleDebug` desde esta carpeta.
