package com.example.avif2jpg

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val selected = mutableListOf<Uri>()
    private lateinit var selectedLabel: TextView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var convertButton: Button
    private lateinit var qualityLabel: TextView
    private var quality = 95

    private val picker = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(100)) { uris ->
        selected.clear()
        selected.addAll(uris)
        selectedLabel.text = if (uris.isEmpty()) "Ningún archivo seleccionado" else "${uris.size} archivo(s) listo(s) para convertir"
        convertButton.isEnabled = uris.isNotEmpty()
        status.text = if (uris.isEmpty()) "Selecciona uno o varios archivos AVIF." else "Puedes convertir todos los archivos seleccionados en un solo lote."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(0xFFF7F8FC.toInt())
        }
        val title = TextView(this).apply {
            text = "AVIF a JPG"
            textSize = 30f
            setTextColor(0xFF172554.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Conversor por lotes · rápido y privado"
            textSize = 15f
            setTextColor(0xFF536079.toInt())
            setPadding(0, dp(6), 0, dp(24))
        })
        val pickButton = Button(this).apply {
            text = "＋  Seleccionar imágenes"
            setOnClickListener {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
        }
        root.addView(pickButton, matchWrap())
        selectedLabel = TextView(this).apply {
            text = "Ningún archivo seleccionado"
            textSize = 15f
            setTextColor(0xFF26334D.toInt())
            setPadding(0, dp(18), 0, dp(18))
        }
        root.addView(selectedLabel)
        root.addView(TextView(this).apply {
            text = "Calidad JPG: 95 %"
            textSize = 14f
            setTextColor(0xFF26334D.toInt())
        })
        qualityLabel = root.getChildAt(root.childCount - 1) as TextView
        val seek = SeekBar(this).apply {
            max = 100
            progress = 95
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    quality = value.coerceIn(50, 100)
                    qualityLabel.text = "Calidad JPG: $quality % (mínimo 50 %)"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(seek, matchWrap())
        convertButton = Button(this).apply {
            text = "Convertir lote a JPG"
            isEnabled = false
            setOnClickListener { convertBatch() }
        }
        val buttonParams = matchWrap().apply { topMargin = dp(18) }
        root.addView(convertButton, buttonParams)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        val progressParams = matchWrap().apply { topMargin = dp(16) }
        root.addView(progress, progressParams)
        status = TextView(this).apply {
            text = "Selecciona uno o varios archivos AVIF."
            textSize = 14f
            setTextColor(0xFF536079.toInt())
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "Los JPG se guardan en Imágenes/AVIF a JPG. La conversión se realiza en este dispositivo."
            textSize = 12f
            setTextColor(0xFF78839A.toInt())
            setPadding(0, dp(28), 0, 0)
        })
        setContentView(root)
    }

    private fun convertBatch() {
        if (selected.isEmpty()) return
        val batch = selected.toList()
        val chosenQuality = quality
        convertButton.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.progress = 0
        status.text = "Iniciando conversión de ${batch.size} archivo(s)…"
        worker.execute {
            var ok = 0
            val errors = mutableListOf<String>()
            batch.forEachIndexed { index, uri ->
                try {
                    convertOne(uri, chosenQuality)
                    ok++
                } catch (e: Exception) {
                    errors.add("${index + 1}: ${e.localizedMessage ?: "formato no compatible"}")
                }
                val done = index + 1
                runOnUiThread {
                    progress.progress = done * 100 / batch.size
                    status.text = "Procesando $done de ${batch.size}…  (${ok} correctos)"
                }
            }
            runOnUiThread {
                convertButton.isEnabled = selected.isNotEmpty()
                status.text = "Lote terminado: $ok de ${batch.size} convertido(s)." +
                    if (errors.isNotEmpty()) "\nNo convertidos: ${errors.size}. Comprueba que sean imágenes AVIF válidas." else "\nGuardados en Imágenes/AVIF a JPG."
                Toast.makeText(this, "$ok de ${batch.size} imágenes convertidas", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun convertOne(uri: Uri, jpgQuality: Int) {
        val source = ImageDecoder.createSource(contentResolver, uri)
        val bitmap = ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
            decoder.isMutableRequired = false
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
        val name = queryDisplayName(uri).substringBeforeLast('.', "imagen")
            .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "imagen" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "${name}_$stamp.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AVIF a JPG")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val output = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo crear el JPG")
        try {
            contentResolver.openOutputStream(output, "w")?.use { stream ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, jpgQuality, stream)) {
                    throw IllegalStateException("Error al codificar JPG")
                }
            } ?: throw IllegalStateException("No se pudo escribir el archivo")
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                contentResolver.update(output, done, null, null)
            }
        } catch (e: Exception) {
            contentResolver.delete(output, null, null)
            throw e
        } finally {
            bitmap.recycle()
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "imagen.avif"
        }
        return "imagen.avif"
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}
